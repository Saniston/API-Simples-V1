﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Agenda.Models
{
    public class Contact
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Campo obrigatório")]
        [MaxLength(60,ErrorMessage ="Este campo deve ter no mínimo 1 caractere e máximo 60")]
        [MinLength(1, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Campo obrigatório")]
        [MaxLength(60, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        [MinLength(1, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Campo obrigatório")]
        [MaxLength(60, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        [MinLength(1, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Campo obrigatório")]
        [MaxLength(60, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        [MinLength(1, ErrorMessage = "Este campo deve ter no mínimo 1 caractere e máximo 60")]
        public string Phone { get; set; }

    }
}
